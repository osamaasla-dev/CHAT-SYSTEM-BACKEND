export const MFA_CODE_LENGTH = 6;
export const MFA_CHALLENGE_TTL_SECONDS = 60;
export const MFA_TEMP_SESSION_TTL_SECONDS = 5 * 60;
export const MFA_CHALLENGE_NAMESPACE = 'mfa:challenge';
export const MFA_USER_POINTER_NAMESPACE = 'mfa:user';
