import { IsString } from 'class-validator';

import { StrongPassword } from 'src/common/validations/strong-password.decorator';

export class ChangePasswordDto {
  @IsString({ message: 'Current password is required' })
  currentPassword!: string;

  @StrongPassword()
  newPassword!: string;
}
